/*
 * main.c
 *
 *  Created on: 26/02/2021
 *      Author: cesar
 */

#include <stdio.h>
int main()
{
 printf("Hello there\n");

 return 0;

}
