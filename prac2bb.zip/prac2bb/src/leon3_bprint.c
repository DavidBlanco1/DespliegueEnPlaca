/*
 * leon3_bprint.c
 *
 *  Created on: Mar 6, 2022
 *      Author: adrian
 */


#include "leon3_bprint.h"
#include "leon3_uart.h"

int8_t leon3_print_string(char*str){
	int i=0;
	while (str[i] !='\0'){
		leon3_putchar(str[i]);
		i++;

	}
	return 0;
}
int8_t leon3_print_uint8(uint8_t i){
	leon3_putchar(i);

	return 0;
}
